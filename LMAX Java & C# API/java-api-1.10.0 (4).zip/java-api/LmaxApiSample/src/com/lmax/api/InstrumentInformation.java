package com.lmax.api;

import java.util.List;

import com.lmax.api.account.LoginCallback;
import com.lmax.api.account.LoginRequest;
import com.lmax.api.orderbook.Instrument;
import com.lmax.api.orderbook.SearchInstrumentCallback;
import com.lmax.api.orderbook.SearchInstrumentRequest;

public class InstrumentInformation implements LoginCallback
{
    private Session session;

    private class PrintInstrumentCallback implements SearchInstrumentCallback
    {
        @Override
        public void onSuccess(final List<Instrument> instruments, final boolean hasMoreResults)
        {
            long offset = -1;

            for (Instrument instrument : instruments)
            {
                System.out.printf(
                        "%s: %d, longSwapPoints: %s, shortSwapPoints: %s%n",
                        instrument.getUnderlying().getSymbol(), instrument.getId(), instrument.getCommercial().getLongSwapPoints(), instrument.getCommercial().getShortSwapPoints());
                offset = instrument.getId();
            }

            if (hasMoreResults)
            {
                searchInstruments(offset);
            }
        }

        @Override
        public void onFailure(final FailureResponse failureResponse)
        {
        }
    };

    private void searchInstruments(long offset)
    {
        String queryString = "CURRENCY";
        System.out.println("Search for: '" + queryString + "' instruments from: " + offset);
        session.searchInstruments(new SearchInstrumentRequest(queryString, offset), new PrintInstrumentCallback());
    }

    @Override
    public void onLoginSuccess(final Session session)
    {
        System.out.println("Login Success");
        this.session = session;
        searchInstruments(0);
    }

    @Override
    public void onLoginFailure(final FailureResponse failureResponse)
    {

    }

    public static void main(String[] args)
    {
        if (args.length != 4)
        {
            System.out.println("Usage " + LoginClient.class.getName() + " <url> <username> <password> [CFD_DEMO|CFD_LIVE]");
            System.exit(-1);
        }

        String url = args[0];
        String username = args[1];
        String password = args[2];
        LoginRequest.ProductType productType = LoginRequest.ProductType.valueOf(args[3].toUpperCase());

        LmaxApi lmaxApi = new LmaxApi(url);
        InstrumentInformation client = new InstrumentInformation();

        lmaxApi.login(new LoginRequest(username, password, productType), client);
    }
}
