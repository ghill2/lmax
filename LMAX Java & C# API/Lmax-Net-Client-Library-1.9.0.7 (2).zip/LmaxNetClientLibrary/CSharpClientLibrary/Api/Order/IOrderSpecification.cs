﻿namespace Com.Lmax.Api.Order
{
    public interface IOrderSpecification : IRequest
    {
    }
}
