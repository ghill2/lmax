using Com.Lmax.Api.Account;

namespace Com.Lmax.Api.Order
{
    /// <summary>
    /// Request to subscribe to execution events.
    /// </summary>
    public class ExecutionSubscriptionRequest : AccountSubscriptionRequest
    {
    }
}
